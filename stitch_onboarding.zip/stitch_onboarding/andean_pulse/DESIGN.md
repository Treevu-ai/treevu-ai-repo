# Design System Specification: Editorial Financial Wellness

## 1. Overview & Creative North Star: "The Living Ledger"
In the evolving landscape of LATAM fintech, trust is not built with rigid grids and cold borders; it is built through transparency, fluidity, and warmth. The Creative North Star for this design system is **"The Living Ledger."** 

We are moving away from the "template" aesthetic of traditional banking. Instead, we embrace an **Editorial High-End** approach. This means utilizing intentional asymmetry, generous white space, and a sophisticated layering of surfaces. The UI should feel like a premium financial journal—authoritative yet deeply accessible. We break the "box" by overlapping elements and using massive typography scales to guide the user’s eye through their financial journey with "Pulse-like" rhythm.

---

## 2. Colors: Tonal Depth & The "No-Line" Rule
Our palette is rooted in a deep, institutional `primary` (#000666) and balanced by the vibrant `secondary` (#006e1c) representing growth and liquidity.

### The "No-Line" Rule
**Explicit Instruction:** Designers are prohibited from using 1px solid borders for sectioning. Boundaries must be defined solely through background color shifts or subtle tonal transitions.
- Use `surface-container-low` for secondary content areas sitting on a `surface` background.
- Use `surface-container-highest` for prominent interactive elements.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers—like stacked sheets of fine Peruvian cotton paper.
- **Level 0 (Base):** `surface` (#f9f9fb)
- **Level 1 (Sections):** `surface-container-low` (#f3f3f5)
- **Level 2 (Cards):** `surface-container-lowest` (#ffffff)
- **Level 3 (Floating):** Semi-transparent `surface-bright` with a 20px backdrop blur.

### The "Glass & Gradient" Rule
To inject "soul" into the interface, use a **Signature Gradient** for primary CTAs: a subtle linear transition from `primary` (#000666) to `primary_container` (#1a237e) at a 135-degree angle. Floating action buttons or high-priority status cards should utilize Glassmorphism (semi-transparent surface colors + blur) to feel integrated into the environment.

---

## 3. Typography: The Editorial Voice
We use a dual-typeface system to balance authority with modern utility.

*   **Display & Headlines (Manrope):** Our "Character" font. Used for large data points (available balance) and section headings. It feels architectural and premium.
*   **Body & Labels (Inter):** Our "Utility" font. Optimized for readability in transaction lists and fine print.

**Key Pairings:**
- **Financial Hero:** `display-lg` (Manrope, 3.5rem) for the available wage amount.
- **Section Narrative:** `headline-sm` (Manrope, 1.5rem) paired with `body-md` (Inter, 0.875rem) for descriptive subtext.
- **Micro-Data:** `label-sm` (Inter, 0.6875rem) in All Caps with +5% letter spacing for "Available Now" indicators.

---

## 4. Elevation & Depth: Tonal Layering
Traditional drop shadows are often a crutch for poor layout. In this system, hierarchy is achieved through **Tonal Layering.**

*   **The Layering Principle:** Place a `surface-container-lowest` card on a `surface-container-low` section. This creates a soft, natural "lift" without visual clutter.
*   **Ambient Shadows:** When an element must float (e.g., a withdrawal confirmation modal), use an ultra-diffused shadow: `Y: 16px, Blur: 32px, Color: on-surface (4% opacity)`. It should mimic natural light, not digital ink.
*   **The "Ghost Border" Fallback:** If accessibility requires a container edge, use a "Ghost Border": `outline-variant` at 15% opacity. Never use 100% opaque borders.

---

## 5. Components: Fluid Primitives

### Buttons
- **Primary:** Gradient fill (`primary` to `primary_container`), `xl` (1.5rem) rounded corners. Text is `on_primary`.
- **Secondary:** Surface-tinted. No border. Use `primary_fixed` background with `on_primary_fixed` text.
- **Tertiary:** Ghost style. No background. Use `primary` text weight 600.

### Cards & Lists
- **Forbid Dividers:** Do not use lines to separate transactions. Use `1.5` (0.375rem) of vertical spacing between `surface-container-lowest` blocks, or use a simple alternating background shift.
- **Earned Wage Card:** A high-contrast card using `secondary_container` to highlight "Available Balance" with a `secondary` (#006e1c) sparkline.

### Input Fields
- **Stateful Design:** Default state is `surface-container-high`. On focus, transition to `surface-container-lowest` with a 2px `primary` ghost-border (20% opacity).
- **Typography:** Input text uses `title-sm` for a more "designed" feel during data entry.

### Signature Component: The "Pulse" Progress Bar
A custom-engineered progress bar for Earned Wage Access. Use a thick 12px track (`surface-container-highest`) with a `secondary` (success green) fill that has a soft outer glow to represent financial "wellness" and liquidity.

---

## 6. Do's and Don'ts

### Do:
*   **Embrace Asymmetry:** Align your "Available Balance" to the left with a massive `display-lg` size, while placing the "Withdraw" button off-center to create a dynamic, editorial feel.
*   **Use Generous Padding:** Use the `8` (2rem) and `10` (2.5rem) spacing tokens to let the data breathe.
*   **Tint Your Neutrals:** Ensure your "light grays" always lean slightly toward the `primary` blue to maintain a "cool and trustworthy" atmosphere.

### Don't:
*   **Don't Use Pure Black:** Always use `on_surface` (#1a1c1d) for text to keep the contrast high but the feel sophisticated.
*   **Don't Use Default Shadows:** Avoid the "fuzzy gray" look. If it's not an ambient, tinted shadow, don't use it.
*   **Don't Box Everything:** Allow some elements, like decorative "wellness" icons or background gradients, to bleed off the edge of the screen to create a sense of scale.